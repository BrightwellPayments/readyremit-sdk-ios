//
//  ReadyRemitSDK.h
//  ReadyRemitSDK
//
//  Created by Mohan Reddy on 26/08/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ReadyRemitSDK.
FOUNDATION_EXPORT double ReadyRemitSDKVersionNumber;

//! Project version string for ReadyRemitSDK.
FOUNDATION_EXPORT const unsigned char ReadyRemitSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ReadyRemitSDK/PublicHeader.h>
